module.exports = {
    "name": "",
    "verbose": false,
    "collectCoverage": true,
    "collectCoverageFrom": ["./src/**"],
    "coverageDirectory": "./out/coverage/",
    "testPathIgnorePatterns": ["/__tests__/functions.js" ],
};
